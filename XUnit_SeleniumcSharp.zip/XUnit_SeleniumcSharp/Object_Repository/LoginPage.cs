﻿
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SeleniumExtras.PageObjects;

namespace XUnit_SeleniumcSharp.Object_Repository
{
    public class LoginPage
    {
        public IWebDriver driver;

        public LoginPage(IWebDriver webDriver)
        {
            this.driver = webDriver;
            PageFactory.InitElements(webDriver, this);
        }

        [FindsBy(How = How.XPath, Using = "//iframe[@id='gsft_main']")] private IWebElement eleiFrame;
        public void switchiFrame()
        {
            driver.SwitchTo().Frame(eleiFrame);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='user_name']")] private IWebElement eleUserNmTxtBox;
        public void SetUserName(string strUserNm)
        {
            eleUserNmTxtBox.SendKeys(strUserNm);
        }

        [FindsBy(How = How.XPath, Using = "//input[@id='user_password']")]
        private IWebElement elePasswordTxtBox;

        public void SetPasswordTxt(string strPwd)
        {
            elePasswordTxtBox.SendKeys(strPwd);
        }

        [FindsBy(How = How.XPath, Using = "//button[@id='sysverb_login']")]
        private IWebElement eleLoginBtn;

        public void ClickLoginBtn()
        {
            eleLoginBtn.Click();
        }
    }
}
