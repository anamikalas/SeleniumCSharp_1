﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XUnit_SeleniumcSharp.Utilities
{
    public class FileOperation
    {
        public string readProperties(string strKey)
        {
            //string strFilePath = @".\Resources\config.properties";
            //string strFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @".\Resources\config.properties");
            string strFilePath = @"C:\Users\anamikla\source\repos\XUnit_SeleniumcSharp\Resources\config.properties";
            var prop = new Dictionary<string, string>();

            foreach (var line in File.ReadLines(strFilePath))
            {
                var parts = line.Split('=', 2);
                if (parts.Length == 2)
                {
                    prop[parts[0].Trim()] = parts[1].Trim();
                }
            }

            prop.TryGetValue(strKey, out string strVal);
            return strVal;
        }
    }
}
