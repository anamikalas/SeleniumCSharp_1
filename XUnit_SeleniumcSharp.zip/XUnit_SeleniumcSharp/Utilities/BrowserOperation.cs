﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XUnit_SeleniumcSharp.Utilities
{
    public class BrowserOperation
    {
        public IWebDriver LaunchChromeBrowser()
        {
            try
            {
                IWebDriver driver = new ChromeDriver();
                driver.Manage().Window.Maximize();
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

                FileOperation objF = new FileOperation();
                driver.Navigate().GoToUrl(objF.readProperties("ST_BE_URL"));
                return driver;
            }
            catch (Exception ex)
            {
                // Log exception or handle it accordingly
                throw;
            }
        }
    }
}