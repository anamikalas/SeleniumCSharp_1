﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XUnit_SeleniumcSharp.Object_Repository;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using XUnit_SeleniumcSharp.Utilities;
using Xunit; // Ensure you have this namespace for Xunit

namespace XUnit_SeleniumcSharp.Test_Scripts
{
    public class BaseClass
    {
        public IWebDriver driver;
        BrowserOperation objB = new BrowserOperation();

        public void LaunchWebApp()
        {
            driver = objB.LaunchChromeBrowser();
        }
    }
}

