﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XUnit_SeleniumcSharp.Object_Repository;
using XUnit_SeleniumcSharp.Utilities;

namespace XUnit_SeleniumcSharp.Test_Scripts
{
    public class LoginPage_Test : BaseClass
    {

        [Fact]
        public void userLogin()
        {
           LaunchWebApp();

            FileOperation objF = new FileOperation();
            LoginPage objL = new LoginPage(driver);
            objL.switchiFrame();
            objL.SetUserName(objF.readProperties("USER_NAME"));
            objL.SetPasswordTxt(objF.readProperties("USER_PWD"));
            objL.ClickLoginBtn();
        }
    }
}
